//soui version: ${SOUI_VER1}.${SOUI_VER2}.${SOUI_VER3}.${SOUI_VER4}
#pragma once

#define SOUI_VER1   2
#define SOUI_VER2   9
#define SOUI_VER3   0
#define SOUI_VER4   3
