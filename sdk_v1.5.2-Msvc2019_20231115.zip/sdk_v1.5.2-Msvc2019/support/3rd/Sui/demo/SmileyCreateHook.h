﻿#pragma once

class SmileyCreateHook
{
public:
    SmileyCreateHook(void);
    ~SmileyCreateHook(void);
};

